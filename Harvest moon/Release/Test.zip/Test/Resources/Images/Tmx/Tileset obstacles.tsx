<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.1" name="TilesetObstacles" tilewidth="16" tileheight="16" tilecount="36" columns="12">
 <image source="../TilesetObstacles.png" width="192" height="48"/>
</tileset>
