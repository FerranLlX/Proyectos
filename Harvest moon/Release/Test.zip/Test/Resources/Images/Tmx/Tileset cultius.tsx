<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.1" name="TilesetCultius" tilewidth="16" tileheight="16" tilecount="121" columns="11">
 <image source="../TilesetCultius.png" width="176" height="176"/>
</tileset>
