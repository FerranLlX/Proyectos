<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="Caseta 2" tilewidth="16" tileheight="16" tilecount="6" columns="2">
 <image source="../Edificis/Caseta 2.png" width="32" height="48"/>
</tileset>
