<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="Edifici estable gallina" tilewidth="16" tileheight="16" tilecount="20" columns="4">
 <image source="../Edificis/Edifici estable gallina.png" width="64" height="80"/>
</tileset>
