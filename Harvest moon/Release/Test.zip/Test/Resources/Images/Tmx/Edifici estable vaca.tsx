<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.2" name="Edifici estable vaca" tilewidth="16" tileheight="16" tilecount="25" columns="5">
 <image source="../Edificis/Edifici estable vaca.png" width="80" height="80"/>
</tileset>
