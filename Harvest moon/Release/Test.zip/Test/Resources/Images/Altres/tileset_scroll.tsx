<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.7.1" name="tileset_scroll" tilewidth="32" tileheight="32" tilecount="84" columns="14">
 <image source="tileset_scroll.png" trans="000000" width="448" height="192"/>
</tileset>
